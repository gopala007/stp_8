package com.stp.auth.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.stp.auth.model.RefCawangan;

public interface RefCawanganRepository extends JpaRepository<RefCawangan, Long> {

}
