package com.stp.auth.restService;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.stp.auth.model.BaranganTemp;
import com.stp.auth.model.Penerbangan;
import com.stp.auth.service.PenerbanganService;

@RestController
public class RestServiceApi {

	@Autowired
	private PenerbanganService penerbanganService;
	
	ArrayList<BaranganTemp> barangant = new ArrayList<BaranganTemp>();

	
	String kemasKiniPeruntukan = "";
	
	@RequestMapping(value = "/kemasKiniPeruntukanPost")
	public void initKemasKiniPeruntkan(@RequestParam(value = "peruntukan") String peruntukan){
		
		kemasKiniPeruntukan = peruntukan;
	}
	
	
	@RequestMapping("/kemasKiniPeruntukan")
	public String getKemasKiniPeruntukan(){
		 
		return kemasKiniPeruntukan;
	}
	
	@RequestMapping("/kemasKiniUpdate")
	public String greeting(@RequestParam(value = "id") Long id) {
		
		List<Penerbangan> p = penerbanganService.getAll();
		ArrayList<PenerbanganPOJO> pData = new ArrayList<PenerbanganPOJO>();
		
		
		for (int i = 0; i < p.size(); i++) {
			if(p.get(i).getPermohonan().getId() == id) {
				
				PenerbanganPOJO pojo = new PenerbanganPOJO();
				pojo.setPenerbanganId(p.get(i).getPenerbanganId());
				pojo.setPenerbangan(p.get(i).getPenerbangan());
				String dtTemp = p.get(i).getTarikhPergi();
				
				String[] data = p.get(i).getTarikhPergi().split("/", 3);
				String date1 = data[2]+"/"+data[1]+"/"+data[0];

				
				pojo.setTarikhPergi(date1);
				System.out.println(date1);
				pojo.setWaktuBerlepas(p.get(i).getWaktuBerlepas());
				pojo.setWaktuTiba(p.get(i).getWaktuTiba());
				pojo.setJenisPesawat(p.get(i).getJenisPesawat());
				pojo.setNoPesawat(p.get(i).getNoPesawat());
				pojo.setDariLokasi(p.get(i).getDariLokasi());
				pojo.setDestinasi(p.get(i).getDestinasi());
				pojo.setNoPesawat(p.get(i).getNoPesawat());
				
				pData.add(pojo);
			}
		}		
		
		String json = new Gson().toJson(pData);
		
		return json;
	}

}