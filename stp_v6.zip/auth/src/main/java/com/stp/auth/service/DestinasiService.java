package com.stp.auth.service;

import java.util.List;

import com.stp.auth.model.Destinasi;

public interface DestinasiService {

	List<Destinasi> getAll();

}
