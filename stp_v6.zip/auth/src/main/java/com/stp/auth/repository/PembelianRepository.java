package com.stp.auth.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.stp.auth.model.Pembelian;
import com.stp.auth.model.Penerbangan;
import com.stp.auth.model.Permohonan;

public interface PembelianRepository extends JpaRepository<Pembelian, Long> {

	List<Pembelian> findByPenerbangan(Penerbangan penerbangan);
	public Pembelian findById(Long id);

}
