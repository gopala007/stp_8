package com.stp.auth.service;

import java.util.List;

import com.stp.auth.model.RefRole;

public interface RefRoleService {

	List<RefRole> getAll();
	
}
