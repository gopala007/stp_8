package com.stp.auth.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.stp.auth.model.RefPesawat;

public interface RefPesawatRepository extends JpaRepository<RefPesawat, Long> {

}
