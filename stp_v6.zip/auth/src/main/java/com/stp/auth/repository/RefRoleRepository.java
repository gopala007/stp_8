package com.stp.auth.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.stp.auth.model.RefRole;

public interface RefRoleRepository extends JpaRepository<RefRole, Long> {

}
