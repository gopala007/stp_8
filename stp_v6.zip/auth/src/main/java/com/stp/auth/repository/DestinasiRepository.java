package com.stp.auth.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.stp.auth.model.Destinasi;

public interface DestinasiRepository extends JpaRepository<Destinasi, Long>{

}
