package com.stp.auth.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.stp.auth.model.RefLokasi;

public interface RefLokasiRepository extends JpaRepository<RefLokasi, Long>{

}
